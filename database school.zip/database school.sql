create database school;

create table students(
studentID int NOT NULL PRIMARY KEY,
firstName varchar(50),
lastName varchar(50),
city varchar(50),
studentAddress varchar(50),
studentPhone varchar(20),
age int
);

create table teachers(
teacherID int NOT NULL PRIMARY KEY,
firstName varchar(50),
lastName varchar(50),
city varchar(50),
teacherAddress varchar(50),
teacherPhone varchar(20),
age int
);

create table courses(
courseID int NOT NULL PRIMARY KEY,
courseName varchar(50),
courseDescription varchar(100)
);

create table lessons(
lessonNumber int NOT NULL PRIMARY KEY,
courseID int FOREIGN KEY REFERENCES courses(courseID),
teacherID int FOREIGN KEY REFERENCES teachers(teacherID),
studentID int FOREIGN KEY REFERENCES students(studentID)
);

create table parents(
parentID int NOT NULL PRIMARY KEY,
parentPhone varchar(20),
studentID int FOREIGN KEY REFERENCES students(studentID),
firstName varchar(50),
lastName varchar(50)
);
