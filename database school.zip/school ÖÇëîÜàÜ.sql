select firstName, lastName
from students
order by firstName

select count(studentID) as amount
from students

select students.firstName as studentFirstName, students.lastName as studentLastName,
parents.firstName as parentFirstName, parents.lastName as parentLastName, parentPhone
from students
inner join parents on students.studentID=parents.studentID

select lessonNumber, courseName, teachers.firstName as teacherFirstName , teachers.lastName as teacherLastName,
students.firstName as studentFirstName ,students.lastName as studentLastName, parents.firstName as parentFirstName, parentPhone 
from lessons
inner join courses on lessons.courseID=courses.courseID
inner join teachers on lessons.teacherID=teachers.teacherID
inner join students on lessons.studentID=students.studentID
inner join parents on lessons.studentID=parents.studentID

select courseName, count(studentID) as amount
from courses
inner join lessons on courses.courseID=lessons.courseID
group by courseName 

select courseName, count(teachers.firstName) as amount
from lessons 
inner join courses on lessons.courseID=courses.courseID
inner join teachers on lessons.teacherID=teachers.teacherID
group by courseName

select students.firstName
from students
WHERE EXISTS (select firstName from teachers where students.firstName=teachers.firstName)


select students.firstName as studentFirstName, students.lastName as studentLastName, studentPhone,
teachers.firstName as teacherFirstName, teachers.lastName as teacherLastName, teacherPhone,
parents.firstName as parentFirstName, parents.lastName as parentLastName, parentPhone
from students
inner join lessons on students.studentID=lessons.studentID
inner join teachers on lessons.teacherID=teachers.teacherID
inner join parents on lessons.studentID=parents.studentID
order by students.firstName

select count(students.firstName) as amount 
from students
inner join lessons on students.studentID=lessons.studentID
inner join teachers on lessons.teacherID=teachers.teacherID
group by teachers.firstName

select students.firstName
from students
WHERE not EXISTS (select studentID from lessons where lessons.studentID=students.studentID)

select teachers.firstname as teacherName, count(studentID) as amount
from teachers
inner join lessons on teachers.teacherID=lessons.teacherID
inner join courses on lessons.courseID=courses.courseID
group by teachers.firstname
having count(teachers.firstName)=2